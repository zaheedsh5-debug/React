// Returns "17:01:05" (24-hour) or "5:01:05 PM" (12-hour)
export function formatTime(zone, date = new Date(), is24h = true) {
  const locale = is24h ? "en-GB" : "en-US";
  return date.toLocaleTimeString(locale, { timeZone: zone });
}