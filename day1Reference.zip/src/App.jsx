import { useEffect, useState } from 'react'
import './App.css'
import Clock from './components/Clock'
import { LoaderCircle } from 'lucide-react'
import ClockList from './components/ClockList'
import AddClockForm from './components/AddClockForm'


function App() {
  const india = { country: "India", zone: "Asia/Kolkata", onClose: () => { alert("onclose india") } }
  const japan = { country: "Japan", zone: "Asia/Tokyo", onClose: () => { alert("onclose Japan") } }
  const usa = { country: "USA", zone: "America/New_York", onClose: () => { alert("onclose USA") } }


  const [clockIds, setClockIds] = useState([
    "india", "usa", "japan"
  ]);;

  const onAdd = (id) => {
    console.log("getting back value from child component : ", id)
    if (clockIds.includes(id)) {
      console.log("Duplicate Clock")
      return;
    } //duplicate handle
    setClockIds([...clockIds, id]);
  }
  const onRemove = (id) => {
    setClockIds(clockIds.filter((cId) => cId !== id))
  }

  return (
    <>
      <header>Welcome, Clock App</header>
      <div className='clock-grid'>
        {/* <Clock {...india} />
        <Clock {...japan} />
        <Clock {...usa} />
        <UserCard id="1" /> */}
      </div>
      <AddClockForm onAdd={onAdd} />
      <ClockList ids={clockIds} onRemove={onRemove} />
      {/* <SignUp /> */}
      {/* <NameTag /> */}
      <footer className='footer'>Made with React @2026</footer>
    </>
  )
}

export default App



const API = "https://jsonplaceholder.typicode.com"

function UserCard({ id }) {
  const [user, setUser] = useState(null);
  useEffect(() => {
    const controller = new AbortController();

    const userTimerId = setTimeout(() => {
      fetch(`${API}/users/${id}`, { signal: controller.signal })
        .then((res) => res.json())
        .then((data) => { console.log("user data : ", data); setUser(data) })
        .catch((err) => {
          console.warn("Error  : ", err?.name);

        });
    }, 2000)
    return () => { controller.abort(); clearTimeout(userTimerId) };
  }, [id])

  if (!user) return <p>Loading... <LoaderCircle className='spin' /></p>;
  return <h3>{user?.name}</h3>
}

function NameTag() {
  const [name, setName] = useState("");

  const onChangeHandler = (e) => {
    console.log("event :", e.target.value)
    setName(e.target.value);
  }
  return <div>
    <input value={name} onChange={onChangeHandler} placeholder='Type name' />
    <p>Hi, {name}!</p>
    <p>{name.length}/30 letters!</p>
  </div>
}


function SignUp() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  //mobile, address, ...etc

  const handleChangeName = (e) => {
    setName(e.target.value)
  }
  const handleChangeEmail = (e) => {
    setEmail(e.target.value)
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("name : ", name, "Email : ", email);
    //apply vlaidations on each
  }
  return (

    <form className='' onSubmit={handleSubmit}>

      <label htmlFor="name">Name :</label>
      <input type="text" value={name} onChange={handleChangeName} />

      <label htmlFor="email">Email :</label>
      <input type="email" value={email} onChange={handleChangeEmail} />

      <button className='custom-btn' type='submit'>Submit</button>
    </form>
  )
}