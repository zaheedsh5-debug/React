export const COUNTRIES = [
  { id: "india", country: "India", zone: "Asia/Kolkata" },
  { id: "japan", country: "Japan", zone: "Asia/Tokyo" },
  { id: "usa", country: "USA", zone: "America/New_York" },
  { id: "uk", country: "UK", zone: "Europe/London" },
  { id: "uae", country: "UAE", zone: "Asia/Dubai" },
  { id: "australia", country: "Australia", zone: "Australia/Sydney" },
];


export const findCounty = (id) => COUNTRIES.find((c) => c.id === id);