import React, { useEffect, useRef, useState } from 'react'
import { COUNTRIES } from '../data/countries';

const AddClockForm = ({ onAdd }) => {
    const [selected, setSelected] = useState("india");
    const selectedRef = useRef(null)

    useEffect(() => {
        selectedRef.current.focus();
    }, [])
    const onHandleSubmit = (e) => {
        e.preventDefault();
        console.log("even on form submit ")
        onAdd(selected);
        selectedRef.current.focus();

    }
    return (
        <form className='custom-form' onSubmit={onHandleSubmit}>
            <select
                className='custom-select'
                onChange={(e) => setSelected(e.target.value)}
                value={selected}
                ref={selectedRef}
            >
                {
                    COUNTRIES.map((c) => (
                        <option key={c.id} value={c.id}>{c.country}</option>
                    ))
                }
            </select>
            <button className='custom-btn' type='submit'>Add</button>
        </form>
    )
}

export default AddClockForm