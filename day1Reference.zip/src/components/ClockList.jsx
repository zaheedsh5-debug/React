import React from 'react'
import { COUNTRIES, findCounty } from '../data/countries'
import Clock from './Clock'

const ClockList = ({ ids, onRemove }) => {
    return (
        <div className='clock-grid'>
            {/* {
                COUNTRIES.map((c) => (
                    <Clock
                        key={c.id}
                        country={c.country}
                        zone={c.zone}
                    />
                ))
            } */}
            {
                ids.map((id) => (
                    <Clock
                        key={id}
                        id={id}
                        {...findCounty(id)}
                        onClose={onRemove}
                    />
                ))
            }
        </div>
    )
}

export default ClockList