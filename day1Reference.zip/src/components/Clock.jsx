import React, { useEffect, useState } from 'react'
import { formatTime } from '../utils/time'
import { Moon, Sun, X } from 'lucide-react'

const Clock = ({ id, country, zone, onClose }) => {
    // console.log("country", country)
    //state memory
    const [now, setNow] = useState(new Date());


    //side effect or rendering
    useEffect(() => {
        const timerId = setInterval(() => setNow(new Date()), 1000);
        // console.log("id :", id)
        return () => clearInterval(timerId);
    }, [now])


    const time = formatTime(zone, now);
    const isAm = Number(time.slice(0, 2)) < 12

    return (
        <div className={isAm ? "clock am" : "clock pm"}>
            <button className='close' onClick={() => onClose(id)}><X /></button>
            {isAm ? <Sun className='' /> : <Moon />}
            <h3 >
                {country}
            </h3>
            <p className="time">{time}</p>
        </div>
    )
}

export default Clock